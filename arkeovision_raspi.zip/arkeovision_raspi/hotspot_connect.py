#!/usr/bin/env python3
"""
Telefon hotspot'una otomatik bağlanma yardımcısı.
Raspberry Pi'da çalıştırın.

Kullanım:
  sudo python3 hotspot_connect.py --ssid "iPhone" --password "12345678"
"""

import argparse
import subprocess
import sys


def connect_wifi(ssid: str, password: str):
    """nmcli ile WiFi'ye bağlan."""
    print(f"[*] '{ssid}' ağına bağlanılıyor...")

    # Önce mevcut bağlantıyı kontrol et
    result = subprocess.run(['nmcli', '-t', '-f', 'ACTIVE,SSID', 'dev', 'wifi'],
                          capture_output=True, text=True)
    for line in result.stdout.strip().split('\n'):
        if line.startswith('yes:') and ssid in line:
            print(f"[✓] Zaten '{ssid}' ağına bağlı!")
            show_ip()
            return True

    # Bağlan
    result = subprocess.run(
        ['nmcli', 'dev', 'wifi', 'connect', ssid, 'password', password],
        capture_output=True, text=True
    )

    if result.returncode == 0:
        print(f"[✓] '{ssid}' ağına başarıyla bağlandı!")
        show_ip()
        return True
    else:
        print(f"[✗] Bağlantı hatası: {result.stderr.strip()}")
        return False


def show_ip():
    """IP adresini göster."""
    result = subprocess.run(['hostname', '-I'], capture_output=True, text=True)
    ip = result.stdout.strip().split()[0] if result.stdout.strip() else 'Bulunamadı'
    print(f"[*] Pi IP adresi: {ip}")
    print(f"[*] Stream URL:   http://{ip}:8080/stream")
    print(f"[*] Capture URL:  http://{ip}:8080/capture")


def setup_autoconnect(ssid: str, password: str):
    """Açılışta otomatik bağlanma ayarla."""
    # wpa_supplicant config
    config = f'''
ctrl_interface=DIR=/var/run/wpa_supplicant GROUP=netdev
update_config=1
country=TR

network={{
    ssid="{ssid}"
    psk="{password}"
    key_mgmt=WPA-PSK
    priority=1
}}
'''
    config_path = '/etc/wpa_supplicant/wpa_supplicant.conf'
    try:
        with open(config_path, 'w') as f:
            f.write(config)
        print(f"[✓] Otomatik bağlantı ayarlandı: {config_path}")
        print("[*] Pi yeniden başlatıldığında otomatik bağlanacak.")
    except PermissionError:
        print("[✗] Root yetkisi gerekli: sudo python3 hotspot_connect.py ...")


def main():
    parser = argparse.ArgumentParser(description='Telefon hotspot bağlantısı')
    parser.add_argument('--ssid', required=True, help='Hotspot adı (ör: iPhone)')
    parser.add_argument('--password', required=True, help='Hotspot şifresi')
    parser.add_argument('--auto', action='store_true', help='Açılışta otomatik bağlan')
    args = parser.parse_args()

    success = connect_wifi(args.ssid, args.password)

    if success and args.auto:
        setup_autoconnect(args.ssid, args.password)


if __name__ == '__main__':
    main()
