# ArkeoVision Raspberry Pi Kurulumu

## Ağ Mimarisi

```
┌──────────────┐
│   TELEFON    │ ← Hotspot açık (WiFi paylaşım)
│  (Hotspot)   │
└──────┬───────┘
       │ WiFi
       ├────────────────────────────┐
       │                            │
┌──────┴───────┐          ┌────────┴────────┐
│ Raspberry Pi │          │   BİLGİSAYAR    │
│  stream.py   │          │  Django :8000    │
│   :8080      │          │  React  :5173    │
└──────────────┘          └─────────────────┘
```

Tüm cihazlar telefonun hotspot'una bağlanır.

## 1. Telefon Hotspot Ayarı

### iPhone
Ayarlar → Kişisel Erişim Noktası → Başkalarının Katılmasına İzin Ver → AÇIK

### Android
Ayarlar → Bağlantılar → Mobil Erişim Noktası → AÇIK

**Not:** Hotspot adı ve şifreyi not edin.

## 2. Raspberry Pi Kurulumu

### Gerekli Paketler
```bash
sudo apt update
sudo apt install python3-picamera2 python3-pil -y
```

### Dosyaları Kopyala
```bash
mkdir -p /home/pi/arkeovision
# stream.py ve hotspot_connect.py dosyalarını bu klasöre kopyalayın
```

### Hotspot'a Bağlan
```bash
# Manuel bağlantı
sudo python3 hotspot_connect.py --ssid "iPhone" --password "12345678"

# Otomatik bağlantı (açılışta)
sudo python3 hotspot_connect.py --ssid "iPhone" --password "12345678" --auto
```

### Kamera Sunucusunu Başlat
```bash
python3 stream.py --port 8080
```

### Otomatik Başlatma (systemd)
```bash
sudo cp arkeovision-cam.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable arkeovision-cam
sudo systemctl start arkeovision-cam

# Logları izle
sudo journalctl -u arkeovision-cam -f
```

## 3. Bilgisayar Kurulumu

### Hotspot'a Bağlan
Bilgisayarınızı da telefonun hotspot'una bağlayın.

### Backend Başlat
```cmd
cd arkeovision_backend
venv\Scripts\activate
python manage.py runserver 0.0.0.0:8000
```

### Frontend Başlat
Pi URL'yi ayarla ve başlat:
```cmd
set VITE_PI_URL=http://PI_IP_ADRESI:8080
npm run dev -- --host
```

Veya `.env` dosyasına ekle:
```
VITE_PI_URL=http://192.168.x.x:8080
```

## 4. IP Adreslerini Bul

### Pi'da
```bash
hostname -I
# Örnek: 172.20.10.5
```

### Bilgisayarda
```cmd
ipconfig
# IPv4 Address: 172.20.10.3
```

### Telefonun Hotspot IP'si
Genellikle: `172.20.10.1` (iPhone) veya `192.168.43.1` (Android)

## 5. Test

1. Pi stream testi: Tarayıcıda `http://PI_IP:8080` aç
2. Backend testi: `http://PC_IP:8000/api/health/`
3. Frontend'de Pi Kamera modunu seç

## Sorun Giderme

| Sorun | Çözüm |
|-------|-------|
| Pi hotspot'a bağlanamıyor | `sudo nmcli dev wifi list` ile ağları kontrol et |
| Kamera bulunamadı | `sudo raspi-config` → Interface → Camera → Enable |
| Stream açılmıyor | `sudo systemctl status arkeovision-cam` ile logları kontrol et |
| Frontend Pi'yı görmüyor | IP adreslerini kontrol et, aynı ağda olduklarından emin ol |
| CORS hatası | stream.py zaten CORS header gönderiyor, tarayıcı cache'ini temizle |
