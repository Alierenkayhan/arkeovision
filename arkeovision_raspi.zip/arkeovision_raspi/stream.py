#!/usr/bin/env python3
"""
ArkeoVision Raspberry Pi Kamera Sunucusu
- /stream         → MJPEG canlı yayın (frontend <img> tag'ında kullanılır)
- /capture        → Tek kare base64 JSON (frontend analiz için çeker)
- /status         → Kamera + motor durumu
- /motor/start    → Motoru başlat (sürekli döndür)
- /motor/stop     → Motoru durdur
- /               → Önizleme sayfası

Motor: MG945 Servo Motor
  Signal → RPi GPIO 12 (BCM) — PWM sinyal
  VCC    → 5V (harici güç kaynağı önerilir)
  GND    → GND

Kullanım:
  python3 stream.py
  python3 stream.py --port 8080
  python3 stream.py --width 1280 --height 720
  python3 stream.py --servo-pin 12 --servo-speed 3
  python3 stream.py --no-motor
"""

import argparse
import base64
import io
import json
import logging
import threading
import time
from http.server import HTTPServer, BaseHTTPRequestHandler
from socketserver import ThreadingMixIn

logging.basicConfig(level=logging.INFO, format='%(asctime)s [%(levelname)s] %(message)s')
logger = logging.getLogger('arkeovision-cam')

# ============================================================
# Kamera Sürücüsü + Frame Buffer
# ============================================================
camera = None
camera_type = None
_frame_buffer = None      # en güncel JPEG bytes
_frame_lock = threading.Lock()
_camera_running = False


def init_camera(width=1280, height=720):
    global camera, camera_type

    # 1) picamera2 (Raspberry Pi OS Bookworm)
    try:
        from picamera2 import Picamera2
        cam = Picamera2()
        config = cam.create_video_configuration(
            main={"size": (width, height), "format": "RGB888"},
            controls={
                "FrameDurationLimits": (33333, 33333),
                "NoiseReductionMode": 2,
                "Sharpness": 2.0,
                "Contrast": 1.2,
                "Brightness": 0.0,
                "Saturation": 1.2,
            }
        )
        cam.configure(config)
        cam.start()
        time.sleep(2)
        cam.set_controls({"AeEnable": True, "AwbEnable": True, "AeExposureMode": 0})
        camera = cam
        camera_type = 'picamera2'
        logger.info(f"picamera2 başlatıldı ({width}x{height})")
        return True
    except Exception as e:
        logger.warning(f"picamera2 bulunamadı: {e}")

    # 2) picamera (eski)
    try:
        import picamera
        cam = picamera.PiCamera()
        cam.resolution = (width, height)
        cam.framerate = 30
        cam.sharpness = 50
        cam.contrast = 20
        cam.brightness = 50
        cam.saturation = 15
        cam.video_denoise = True
        cam.exposure_mode = 'auto'
        cam.awb_mode = 'auto'
        time.sleep(2)
        camera = cam
        camera_type = 'picamera'
        logger.info(f"picamera başlatıldı ({width}x{height})")
        return True
    except Exception as e:
        logger.warning(f"picamera bulunamadı: {e}")

    # 3) OpenCV (USB kamera)
    try:
        import cv2
        cam = cv2.VideoCapture(0)
        cam.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc('M', 'J', 'P', 'G'))
        cam.set(cv2.CAP_PROP_FRAME_WIDTH, width)
        cam.set(cv2.CAP_PROP_FRAME_HEIGHT, height)
        cam.set(cv2.CAP_PROP_FPS, 30)
        cam.set(cv2.CAP_PROP_BUFFERSIZE, 1)
        if cam.isOpened():
            camera = cam
            camera_type = 'opencv'
            logger.info(f"OpenCV kamera başlatıldı ({width}x{height})")
            return True
        else:
            cam.release()
    except Exception as e:
        logger.warning(f"OpenCV bulunamadı: {e}")

    logger.error("Hiçbir kamera bulunamadı!")
    return False


def _capture_one_jpeg(quality=85):
    """Kameradan tek kare al, JPEG bytes döndür."""
    try:
        if camera_type == 'picamera2':
            from PIL import Image
            frame = camera.capture_array()
            img = Image.fromarray(frame)
            buf = io.BytesIO()
            img.save(buf, format='JPEG', quality=quality)
            return buf.getvalue()

        elif camera_type == 'picamera':
            buf = io.BytesIO()
            camera.capture(buf, format='jpeg', quality=quality)
            return buf.getvalue()

        elif camera_type == 'opencv':
            import cv2
            camera.grab()
            ret, frame = camera.retrieve()
            if ret:
                _, buf = cv2.imencode('.jpg', frame, [cv2.IMWRITE_JPEG_QUALITY, quality])
                return buf.tobytes()
    except Exception as e:
        logger.warning(f"Kare yakalama hatası: {e}")
    return None


def _frame_producer():
    """Arka planda sürekli kare yakalayan iş parçacığı (~30 fps)."""
    global _frame_buffer, _camera_running
    _camera_running = True
    logger.info("Frame producer başlatıldı")
    while _camera_running:
        frame = _capture_one_jpeg(quality=85)
        if frame:
            with _frame_lock:
                _frame_buffer = frame
        time.sleep(0.033)
    logger.info("Frame producer durduruldu")


def get_latest_frame():
    """Thread-safe: en güncel kareyi döndür."""
    with _frame_lock:
        return _frame_buffer


# ============================================================
# Servo Motor Kontrolü — MG945
#
#   Servo     Raspberry Pi (BCM)
#   ------    ------------------
#   Signal →  GPIO 12  (PWM sinyal)
#   VCC    →  5V (harici güç kaynağı önerilir)
#   GND    →  GND
#
#   PWM: 50 Hz, duty cycle 2.5% (0°) – 12.5% (180°)
#   Sweep: 0° → 180° → 0° sürekli ileri-geri
#
# ============================================================
motor_enabled = False
motor_active  = False
motor_lock    = threading.Lock()
_motor_pwm    = None
_sweep_thread = None
_sweep_running = False

_servo_pin   = 12   # BCM sinyal pini
_servo_speed = 3    # Sweep hızı: her adımda kaç derece


def _angle_to_duty(angle):
    """Açıyı (0-180) duty cycle'a çevir (2.5 – 12.5)."""
    return 2.5 + (angle / 180.0) * 10.0


def _sweep_worker():
    """Arka planda servo'yu 0°↔180° sürekli sweep eden thread."""
    global _sweep_running
    angle = 0
    direction = 1  # 1 = ileri, -1 = geri
    while _sweep_running:
        duty = _angle_to_duty(angle)
        try:
            _motor_pwm.ChangeDutyCycle(duty)
        except Exception:
            break
        time.sleep(0.03)
        angle += direction * _servo_speed
        if angle >= 180:
            angle = 180
            direction = -1
        elif angle <= 0:
            angle = 0
            direction = 1
    # Sweep bitince sinyal göndermeyi kes (servo titremesini önler)
    try:
        _motor_pwm.ChangeDutyCycle(0)
    except Exception:
        pass


def init_motor(pin, speed):
    global _servo_pin, _servo_speed, motor_enabled, _motor_pwm
    _servo_pin = pin
    _servo_speed = speed
    try:
        import RPi.GPIO as GPIO
        GPIO.setmode(GPIO.BCM)
        GPIO.setwarnings(False)
        GPIO.setup(_servo_pin, GPIO.OUT)
        _motor_pwm = GPIO.PWM(_servo_pin, 50)  # 50 Hz servo PWM
        _motor_pwm.start(0)
        motor_enabled = True
        logger.info(f"MG945 Servo başlatıldı — Pin:{_servo_pin}, hız:{_servo_speed}°/adım")
        return True
    except Exception as e:
        logger.warning(f"Servo GPIO başlatılamadı (sadece Raspberry Pi'de çalışır): {e}")
        motor_enabled = False
        return False


def motor_start():
    """Servo sweep başlat (0°↔180° sürekli)."""
    global motor_active, _sweep_thread, _sweep_running
    if not motor_enabled:
        logger.info("Motor devre dışı, başlatılmadı")
        return
    with motor_lock:
        if motor_active:
            return
        _sweep_running = True
        _sweep_thread = threading.Thread(target=_sweep_worker, daemon=True)
        _sweep_thread.start()
        motor_active = True
        logger.info("Servo sweep başlatıldı")


def motor_stop():
    """Servo sweep durdur."""
    global motor_active, _sweep_running
    if not motor_enabled:
        return
    with motor_lock:
        _sweep_running = False
        if _sweep_thread:
            _sweep_thread.join(timeout=2)
        motor_active = False
        logger.info("Servo sweep durduruldu")


# ============================================================
# HTTP Sunucusu — Çok iş parçacıklı (ThreadingMixIn)
# ============================================================
class ThreadedHTTPServer(ThreadingMixIn, HTTPServer):
    """Her bağlantı için ayrı thread — stream diğer istekleri bloklamaz."""
    daemon_threads = True


class CameraHandler(BaseHTTPRequestHandler):

    def _cors_headers(self):
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')

    def do_OPTIONS(self):
        self.send_response(200)
        self._cors_headers()
        self.end_headers()

    def do_GET(self):
        if self.path == '/stream':
            self._handle_stream()
        elif self.path.startswith('/capture'):
            self._handle_capture()
        elif self.path == '/status':
            self._handle_status()
        elif self.path == '/':
            self._handle_preview()
        else:
            self.send_error(404)

    def do_POST(self):
        if self.path == '/motor/start':
            self._handle_motor_start()
        elif self.path == '/motor/stop':
            self._handle_motor_stop()
        else:
            self.send_error(404)

    # -------- Kamera --------

    def _handle_stream(self):
        """MJPEG canlı yayın — frame buffer'dan okur."""
        self.send_response(200)
        self.send_header('Content-Type', 'multipart/x-mixed-replace; boundary=frame')
        self._cors_headers()
        self.send_header('Cache-Control', 'no-cache, no-store, must-revalidate')
        self.send_header('Pragma', 'no-cache')
        self.end_headers()

        # İlk kare gelene kadar kısa bekle
        for _ in range(30):
            if get_latest_frame():
                break
            time.sleep(0.1)

        try:
            while True:
                frame = get_latest_frame()
                if frame:
                    self.wfile.write(b'--frame\r\n')
                    self.wfile.write(b'Content-Type: image/jpeg\r\n')
                    self.wfile.write(f'Content-Length: {len(frame)}\r\n'.encode())
                    self.wfile.write(b'\r\n')
                    self.wfile.write(frame)
                    self.wfile.write(b'\r\n')
                    self.wfile.flush()
                time.sleep(0.033)  # ~30 fps
        except (BrokenPipeError, ConnectionResetError):
            pass

    def _handle_capture(self):
        """Tek kare — base64 JSON döndür."""
        frame = get_latest_frame()
        if not frame:
            frame = _capture_one_jpeg(quality=90)
        if frame:
            b64 = base64.b64encode(frame).decode('utf-8')
            data = json.dumps({
                'success': True,
                'image': b64,
                'timestamp': time.time(),
                'camera': camera_type,
            })
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self._cors_headers()
            self.end_headers()
            self.wfile.write(data.encode())
        else:
            self.send_response(500)
            self.send_header('Content-Type', 'application/json')
            self._cors_headers()
            self.end_headers()
            self.wfile.write(json.dumps({'success': False, 'error': 'Kare yakalanamadı'}).encode())

    def _handle_status(self):
        """Kamera + motor durumu."""
        data = json.dumps({
            'online': camera is not None,
            'camera_type': camera_type,
            'motor_enabled': motor_enabled,
            'motor_active': motor_active,
            'timestamp': time.time(),
        })
        self.send_response(200)
        self.send_header('Content-Type', 'application/json')
        self._cors_headers()
        self.end_headers()
        self.wfile.write(data.encode())

    def _handle_preview(self):
        """Tarayıcıda önizleme sayfası."""
        html = f"""<!DOCTYPE html>
<html>
<head><title>ArkeoVision Pi Camera</title>
<style>
  body {{ background: #1c1917; color: #d4af37; font-family: monospace; text-align: center; padding: 20px; }}
  img {{ max-width: 100%; border: 2px solid #d4af37; border-radius: 8px; }}
  .info {{ margin: 10px 0; color: #a8a29e; font-size: 14px; }}
  button {{ margin: 5px; padding: 8px 16px; background: #d4af37; border: none; border-radius: 4px; cursor: pointer; font-weight: bold; }}
</style>
</head>
<body>
  <h1>ArkeoVision Pi Kamera</h1>
  <img src="/stream" alt="Canlı Yayın">
  <p class="info">Kamera: {camera_type or 'Yok'} | Durum: {'Aktif' if camera else 'Kapalı'}</p>
  <p class="info">Motor: {'Çalışıyor' if motor_active else ('Hazır' if motor_enabled else 'Devre Dışı')}</p>
  <p class="info">Stream: /stream | Capture: /capture | Status: /status</p>
  <br>
  <button onclick="fetch('/motor/start',{{method:'POST'}})">Motor Başlat</button>
  <button onclick="fetch('/motor/stop',{{method:'POST'}})">Motor Durdur</button>
</body>
</html>"""
        self.send_response(200)
        self.send_header('Content-Type', 'text/html')
        self._cors_headers()
        self.end_headers()
        self.wfile.write(html.encode())

    # -------- Motor --------

    def _handle_motor_start(self):
        motor_start()
        self._json_response({'success': True, 'motor': 'started', 'enabled': motor_enabled})

    def _handle_motor_stop(self):
        motor_stop()
        self._json_response({'success': True, 'motor': 'stopped'})

    def _json_response(self, data: dict, status: int = 200):
        body = json.dumps(data).encode()
        self.send_response(status)
        self.send_header('Content-Type', 'application/json')
        self._cors_headers()
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, format, *args):
        if '/stream' not in str(args[0]):
            logger.info(f"{self.client_address[0]} - {args[0]}")


def main():
    parser = argparse.ArgumentParser(description='ArkeoVision Pi Kamera Sunucusu')
    parser.add_argument('--port', type=int, default=8080, help='HTTP port (varsayılan: 8080)')
    parser.add_argument('--width', type=int, default=1280, help='Çözünürlük genişlik')
    parser.add_argument('--height', type=int, default=720, help='Çözünürlük yükseklik')
    parser.add_argument('--servo-pin', type=int, default=12, metavar='PIN',
                        help='Servo sinyal BCM GPIO pini (varsayılan: 12)')
    parser.add_argument('--servo-speed', type=int, default=3,
                        help='Servo sweep hızı, derece/adım (varsayılan: 3)')
    parser.add_argument('--no-motor', action='store_true',
                        help='Motor kontrolünü devre dışı bırak')
    args = parser.parse_args()

    if not init_camera(args.width, args.height):
        logger.error("Kamera başlatılamadı! Çıkılıyor...")
        return

    # Arka plan frame yakalayıcısını başlat
    producer = threading.Thread(target=_frame_producer, daemon=True)
    producer.start()

    if not args.no_motor:
        init_motor(args.servo_pin, args.servo_speed)
        motor_start()
    else:
        logger.info("Motor devre dışı (--no-motor)")

    server = ThreadedHTTPServer(('0.0.0.0', args.port), CameraHandler)
    logger.info(f"Sunucu başlatıldı: http://0.0.0.0:{args.port}")
    logger.info(f"Canlı yayın:   http://0.0.0.0:{args.port}/stream")
    logger.info(f"Tek kare:      http://0.0.0.0:{args.port}/capture")
    logger.info(f"Motor başlat:  POST http://0.0.0.0:{args.port}/motor/start")
    logger.info(f"Motor durdur:  POST http://0.0.0.0:{args.port}/motor/stop")

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        logger.info("Sunucu kapatılıyor...")
        global _camera_running
        _camera_running = False
        motor_stop()
        server.shutdown()


if __name__ == '__main__':
    main()
